export default function DiscussionsPage() {
  return (
    <div className="flex-grow flex items-center justify-center h-full">
      <div className="text-center">
        <p className="text-lg opacity-80">
          Sélectionnez une discussion pour commencer à discuter.
        </p>
      </div>
    </div>
  );
}

