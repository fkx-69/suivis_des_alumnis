export interface Notification {
  id: number;
  destinataire: number;
  message: string;
  date: string;
}
