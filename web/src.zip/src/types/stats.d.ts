export interface SituationProStat {
  situation: string;
  count: number;
}

export interface DomaineStat {
  domaine: string;
  count: number;
}
